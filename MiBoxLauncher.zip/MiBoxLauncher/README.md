# Mi Launcher — Xiaomi Mi Box için hafif Android TV launcher

Kotlin + Jetpack Compose ile yazılmış, tamamen kumandayla kullanılan sade bir ana ekran uygulaması.
**İnternet izni yok, reklam/analiz yok, arka plan servisi yok.** Yalnızca ağ durumunu göstermek için
`ACCESS_NETWORK_STATE` (kullanıcıya sorulmayan normal izin) kullanır.

> **Dürüst durum notu:** Bu kod, Android SDK'sı olmayan bir ortamda yazıldı. **Derlenmedi ve gerçek
> cihazda test edilmedi.** İlk GitHub Actions derlemesinde küçük bir derleme hatası çıkabilir;
> çıkarsa Actions günlüğünü (hata satırlarını) paylaşın, düzeltilir.

## Özellikler
- Üstte saat/tarih, bağlantı durumu (Wi‑Fi/Ethernet/çevrimdışı), Ayarlar düğmesi
- Favoriler, Son kullanılanlar, Tüm uygulamalar (yüklü uygulamalar otomatik listelenir)
- OK = aç, **OK'a basılı tut = menü** (favori ekle/çıkar, sola/sağa taşıyarak sıralama, gizle, uygulama bilgisi)
- Geri tuşu launcher'dan çıkmaz; menüleri/ayarları kapatır, ana ekranda başa döner
- Ana ekran tuşu: ayarlardayken bile ana ekrana döner
- Ayarlar: tema (koyu varsayılan), arka plan rengi/görseli, saat, son kullanılanlar, kart boyutu,
  animasyon seviyesi (tam/azaltılmış/kapalı), uygulama yönetimi, varsayılan launcher, hata kaydı, sistem bilgisi
- Uygulama listesi yalnızca kurulum/kaldırma/güncellemede yeniden taranır; simgeler ~6 MB'lık önbellekte

## 1) GitHub'da depo oluşturma
1. https://github.com adresine girin, hesabınız yoksa ücretsiz açın.
2. Sağ üstte **+ → New repository**. Ad: `mi-launcher`. **Public** veya Private fark etmez. **Create repository**.

## 2) Dosyaları yükleme
ZIP'i bilgisayarınızda açın. İçindeki **`MiBoxLauncher` klasörünün İÇİNDEKİ** her şeyi (klasörün kendisini değil)
depoya yükleyin: `app/`, `.github/`, `build.gradle.kts`, `settings.gradle.kts`, `gradle.properties`, `README.md`…

- Depo sayfasında **uploading an existing file** bağlantısına tıklayın, dosya ve klasörleri sürükleyip bırakın, **Commit changes**.
- **Önemli:** `.github` klasörü gizli sayıldığı için bazen sürüklemede atlanır. Depoda `.github/workflows/build.yml`
  görünmüyorsa: **Add file → Create new file**, ad kutusuna `.github/workflows/build.yml` yazın ve ZIP'teki
  dosyanın içeriğini yapıştırıp commit edin.
- Git biliyorsanız: `git init && git add . && git commit -m ilk && git branch -M main && git remote add origin <depo-adresi> && git push -u origin main`

## 3) APK'yı derleme ve indirme
1. Depoda **Actions** sekmesine girin. Yükleme yapınca **Build APK** otomatik başlar (ilk derleme ~5–10 dk).
   Gerekirse **Build APK → Run workflow** ile elle başlatın.
2. Çalışma yeşil tik alınca içine girin, en altta **Artifacts** bölümünde iki dosya görürsünüz:
   - `MiLauncher-release-apk` → **önerilen** (R8 ile küçültülmüş, daha akıcı; debug anahtarıyla imzalı, kişisel kullanım için)
   - `MiLauncher-debug-apk` → yedek (derleme sorunu çıkarsa bu her zaman üretilir)
3. İndirip ZIP'ten çıkarın (içinde `.apk` vardır).

## 4) Mi Box'a kurma
**Yöntem A — ADB (önerilen)**
1. Mi Box: Ayarlar → Cihaz tercihleri → Hakkında → **Derleme** satırına 7 kez OK → Geliştirici seçenekleri → **USB hata ayıklama / ADB** açık.
2. Mi Box ile bilgisayar aynı ağda olsun; Mi Box IP'si: Ayarlar → Ağ.
3. Bilgisayarda (Android platform-tools kurulu): `adb connect MIBOX_IP:5555` → `adb install -r app-release.apk`
   (APK adı farklıysa onu yazın).

**Yöntem B — USB bellek**: APK'yı USB belleğe kopyalayın, Mi Box'a takın, Play Store'dan bir dosya yöneticisi
(ör. "File Commander") kurun, APK'ya OK, istenirse "Bilinmeyen kaynaklara izin ver".

## 5) Varsayılan ana ekran yapma
Uygulama Android'in standart HOME filtresini taşır, yani **seçilebilir**; ancak Android TV sürümüne göre
sistem seçiciyi göstermeyebilir. Sırayla deneyin:
1. Uygulamada **Ayarlar → Varsayılan ana ekran uygulaması** (sisteme standart yollarla yönlendirir).
2. Ana ekran tuşuna basıp "her zaman / bir kez" seçici çıkarsa **Her zaman** deyin.
3. Olmazsa ADB ile (sizin çalıştırdığınız standart komut; uygulama bunu gizlice yapmaz):
   `adb shell cmd package set-home-activity com.mibox.launcher/.MainActivity`
4. Geri almak için genelde: Ayarlar → Uygulamalar → Mi Launcher → **Varsayılanları temizle**
   veya uygulamayı kaldırın. Sistem launcher'ı devre dışı bırakılmaz.

## Test durumu (şeffaf liste)
| Konu | Durum |
|---|---|
| Kaynak yapısı, XML/YAML geçerliliği, parantez dengesi | Kontrol edildi |
| Gradle derlemesi / APK üretimi | **Yapılmadı** (bu ortamda SDK yok) — GitHub Actions'ta ilk kez derlenecek |
| Birim testleri (sıralama mantığı) | Yazıldı, çalıştırılmadı (Actions'ta çalışır, başarısız olsa APK yine üretilir) |
| D-pad gezinmesi, uzun OK, Geri tuşu | **Gerçek cihazda test edilmedi** |
| Varsayılan launcher seçimi | **Test edilmedi**; Android TV sürümüne bağlı |
| Yerel görsel arka plan | Cihazda dosya seçici yoksa çalışmaz (uyarı gösterir) |
| Mi Box sürümü uyumu | Doğrulanmadı; `minSdk 24` (Android 7+) hedeflendi, `app/build.gradle.kts` içinde değiştirilebilir |

Launcher'ın düşük kaynak tüketimi hedeflenmiştir (sürekli döngü/polling yok, önbellekli simgeler); tüm cihazı
hızlandıracağı iddia edilmez ve ölçüm yapılmamıştır.

## Yerel derleme (isteğe bağlı)
Android Studio ile klasörü açın → **Build → Build APK(s)**. Komut satırı: Gradle 8.9 + JDK 17 ile `gradle assembleRelease`.
Hata günlüğü açıkken: `adb pull /sdcard/Android/data/com.mibox.launcher/files/launcher.log`
