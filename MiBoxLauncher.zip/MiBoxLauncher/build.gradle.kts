// AGP 8.5.2 <-> Gradle 8.9 <-> Kotlin 1.9.24 <-> Compose compiler 1.5.14 uyumlu setidir.
plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
}
