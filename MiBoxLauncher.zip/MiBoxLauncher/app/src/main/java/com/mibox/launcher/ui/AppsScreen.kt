package com.mibox.launcher.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import com.mibox.launcher.data.LauncherModel
import com.mibox.launcher.data.LauncherPrefs
import com.mibox.launcher.data.UiModel

@Composable
fun AppsScreen(model: LauncherModel, prefs: LauncherPrefs, ui: UiModel, onBack: () -> Unit) {
    val c = LocalColors.current
    val first = remember { FocusRequester() }
    BackHandler(onBack = onBack)
    LaunchedEffect(ui.manage.isNotEmpty()) { first.requestSafely() }

    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        Column(Modifier.width(900.u()).fillMaxHeight().padding(top = 28.u())) {
            BasicText("Uygulama yönetimi", style = TextStyle(color = c.text, fontSize = 34.us(), fontWeight = FontWeight.Bold))
            BasicText(
                "Sağ/sol: seçenekler arasında geç — OK: değiştir",
                style = TextStyle(color = c.textDim, fontSize = 16.us()),
                modifier = Modifier.padding(top = 4.u()),
            )
            Spacer(Modifier.height(10.u()))
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.u()),
                contentPadding = PaddingValues(top = 8.u(), bottom = 40.u()),
            ) {
                items(ui.manage, key = { it.pkg }) { app ->
                    val hidden = app.pkg in prefs.hidden
                    val fav = app.pkg in prefs.favorites
                    Row(
                        Modifier.fillMaxWidth().height(60.u()),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.u()),
                    ) {
                        AppIcon(app, 40.u())
                        BasicText(
                            app.label,
                            style = TextStyle(color = if (hidden) c.textDim else c.text, fontSize = 19.us()),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f),
                        )
                        Chip(
                            text = if (hidden) "Gizli" else "Görünür",
                            active = !hidden,
                            modifier = if (app.pkg == ui.manage.first().pkg) Modifier.focusRequester(first) else Modifier,
                        ) { model.setHidden(app.pkg, !hidden) }
                        Chip(text = if (fav) "Favori" else "Favori değil", active = fav) { model.toggleFavorite(app.pkg) }
                    }
                }
            }
        }
    }
}

@Composable
private fun Chip(text: String, active: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val c = LocalColors.current
    FocusBox(
        modifier = modifier.height(44.u()).width(150.u()),
        shape = RoundedCornerShape(22.u()),
        normal = if (active) c.accent.copy(alpha = 0.22f) else c.surface,
        onClick = onClick,
    ) {
        BasicText(
            text,
            style = TextStyle(color = c.text, fontSize = 16.us(), fontWeight = FontWeight.Medium),
            modifier = Modifier.align(Alignment.Center),
        )
    }
}
