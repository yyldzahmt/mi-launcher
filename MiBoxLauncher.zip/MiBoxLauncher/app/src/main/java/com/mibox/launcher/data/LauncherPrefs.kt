package com.mibox.launcher.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

enum class AnimLevel { FULL, REDUCED, OFF }
enum class CardSize { SMALL, MEDIUM, LARGE }

data class LauncherPrefs(
    val darkTheme: Boolean = true,
    val showClock: Boolean = true,
    val showRecents: Boolean = true,
    val cardSize: CardSize = CardSize.MEDIUM,
    val anim: AnimLevel = AnimLevel.FULL,
    val bgIndex: Int = 0,
    val bgImageUri: String? = null,
    val debugLog: Boolean = false,
    val favorites: List<String> = emptyList(),
    val order: List<String> = emptyList(),
    val hidden: Set<String> = emptySet(),
    val recents: List<String> = emptyList(),
)

/** Basit ayarlar icin SharedPreferences; veritabani yok. */
class PrefsStore(context: Context) {
    private val sp = context.getSharedPreferences("launcher_prefs", Context.MODE_PRIVATE)
    private val _state = MutableStateFlow(load())
    val state: StateFlow<LauncherPrefs> = _state

    private fun readList(key: String): List<String> =
        (sp.getString(key, "") ?: "").split('\n').filter { it.isNotEmpty() }

    private inline fun <reified E : Enum<E>> readEnum(key: String, def: E): E {
        val name = sp.getString(key, null)
        return enumValues<E>().firstOrNull { it.name == name } ?: def
    }

    private fun load() = LauncherPrefs(
        darkTheme = sp.getBoolean("dark", true),
        showClock = sp.getBoolean("clock", true),
        showRecents = sp.getBoolean("recents_on", true),
        cardSize = readEnum("card", CardSize.MEDIUM),
        anim = readEnum("anim", AnimLevel.FULL),
        bgIndex = sp.getInt("bg", 0),
        bgImageUri = sp.getString("bg_uri", null),
        debugLog = sp.getBoolean("debug", false),
        favorites = readList("fav"),
        order = readList("order"),
        hidden = readList("hidden").toSet(),
        recents = readList("recents"),
    )

    @Synchronized
    fun update(transform: (LauncherPrefs) -> LauncherPrefs) {
        val old = _state.value
        val new = transform(old)
        if (new == old) return
        _state.value = new
        sp.edit()
            .putBoolean("dark", new.darkTheme)
            .putBoolean("clock", new.showClock)
            .putBoolean("recents_on", new.showRecents)
            .putString("card", new.cardSize.name)
            .putString("anim", new.anim.name)
            .putInt("bg", new.bgIndex)
            .putString("bg_uri", new.bgImageUri)
            .putBoolean("debug", new.debugLog)
            .putString("fav", new.favorites.joinToString("\n"))
            .putString("order", new.order.joinToString("\n"))
            .putString("hidden", new.hidden.joinToString("\n"))
            .putString("recents", new.recents.joinToString("\n"))
            .apply()
    }
}
