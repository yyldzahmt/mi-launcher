package com.mibox.launcher.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import com.mibox.launcher.data.AnimLevel
import com.mibox.launcher.data.CardSize
import com.mibox.launcher.data.LauncherPrefs
import com.mibox.launcher.data.PrefsStore
import com.mibox.launcher.system.systemInfoLines

@Composable
fun SettingsScreen(
    prefs: LauncherPrefs,
    store: PrefsStore,
    host: HostActions,
    resumeTick: Int,
    onApps: () -> Unit,
    onBack: () -> Unit,
) {
    val c = LocalColors.current
    val ctx = LocalContext.current
    val first = remember { FocusRequester() }
    BackHandler(onBack = onBack)
    LaunchedEffect(Unit) { first.requestSafely() }

    val isDefault = remember(resumeTick) { host.isDefaultHome() }
    val info = remember(resumeTick) { systemInfoLines(ctx) }

    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        Column(Modifier.width(900.u()).fillMaxHeight().padding(top = 28.u())) {
            BasicText("Ayarlar", style = TextStyle(color = c.text, fontSize = 34.us(), fontWeight = FontWeight.Bold))
            Spacer(Modifier.height(14.u()))
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.u()),
                contentPadding = PaddingValues(top = 8.u(), bottom = 40.u()),
            ) {
                item {
                    SettingRow("Tema", if (prefs.darkTheme) "Koyu" else "Açık", first) {
                        store.update { it.copy(darkTheme = !it.darkTheme) }
                    }
                }
                item {
                    SettingRow("Arka plan rengi (koyu tema)", BgPresetNames[prefs.bgIndex.coerceIn(0, BgPresetNames.lastIndex)]) {
                        store.update { it.copy(bgIndex = (it.bgIndex + 1) % BgPresetNames.size) }
                    }
                }
                item {
                    SettingRow("Arka plan görseli", if (prefs.bgImageUri != null) "Seçili" else "Yok") {
                        host.pickBackgroundImage()
                    }
                }
                if (prefs.bgImageUri != null) {
                    item { SettingRow("Arka plan görselini kaldır") { store.update { it.copy(bgImageUri = null) } } }
                }
                item {
                    SettingRow("Saat ve tarih", if (prefs.showClock) "Açık" else "Kapalı") {
                        store.update { it.copy(showClock = !it.showClock) }
                    }
                }
                item {
                    SettingRow("Son kullanılanlar satırı", if (prefs.showRecents) "Açık" else "Kapalı") {
                        store.update { it.copy(showRecents = !it.showRecents) }
                    }
                }
                item {
                    SettingRow(
                        "Kart boyutu",
                        when (prefs.cardSize) { CardSize.SMALL -> "Küçük"; CardSize.MEDIUM -> "Orta"; CardSize.LARGE -> "Büyük" },
                    ) {
                        store.update {
                            val v = CardSize.values()
                            it.copy(cardSize = v[(it.cardSize.ordinal + 1) % v.size])
                        }
                    }
                }
                item {
                    SettingRow(
                        "Animasyonlar",
                        when (prefs.anim) { AnimLevel.FULL -> "Tam"; AnimLevel.REDUCED -> "Azaltılmış"; AnimLevel.OFF -> "Kapalı" },
                    ) {
                        store.update {
                            val v = AnimLevel.values()
                            it.copy(anim = v[(it.anim.ordinal + 1) % v.size])
                        }
                    }
                }
                item { SettingRow("Uygulama yönetimi (göster/gizle, favori)", "›", onClick = onApps) }
                item {
                    SettingRow("Varsayılan ana ekran uygulaması", if (isDefault) "Bu uygulama" else "Değil — seç") {
                        host.openDefaultLauncherSettings()
                    }
                }
                item { SettingRow("Önbellek ve uygulama verisi (Android ayarları)", "›") { host.openAppDetails(ctx.packageName) } }
                item {
                    SettingRow("Geliştirici hata kayıtları", if (prefs.debugLog) "Açık" else "Kapalı") {
                        store.update { it.copy(debugLog = !it.debugLog) }
                    }
                }
                info.forEach { (k, v) -> item { SettingRow(k, v) {} } }
            }
        }
    }
}
