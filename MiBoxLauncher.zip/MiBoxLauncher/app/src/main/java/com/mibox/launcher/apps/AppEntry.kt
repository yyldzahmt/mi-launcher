package com.mibox.launcher.apps

/** Android'e bagimli olmayan, saf veri sinifi. */
data class AppEntry(val pkg: String, val cls: String, val label: String)

/** Siralama mantigi (birim testle denenir). */
object AppOrdering {
    /** [apps] alfabetik gelir; [order] icindekiler once, kalanlar alfabetik sirayla sona eklenir. */
    fun applyOrder(apps: List<AppEntry>, order: List<String>): List<AppEntry> {
        val byPkg = apps.associateBy { it.pkg }
        val ordered = order.mapNotNull { byPkg[it] }.distinctBy { it.pkg }
        val seen = HashSet<String>()
        ordered.forEach { seen.add(it.pkg) }
        return ordered + apps.filter { it.pkg !in seen }
    }

    /** [pkg] ogesini [delta] kadar (±1) kaydirir; sinir disina cikmaz. */
    fun move(list: List<String>, pkg: String, delta: Int): List<String> {
        val i = list.indexOf(pkg)
        if (i < 0) return list
        val j = (i + delta).coerceIn(0, list.lastIndex)
        if (i == j) return list
        val m = list.toMutableList()
        val t = m[i]; m[i] = m[j]; m[j] = t
        return m
    }

    fun pushRecent(recents: List<String>, pkg: String, max: Int = 12): List<String> =
        (listOf(pkg) + recents.filter { it != pkg }).take(max)

    fun toggle(list: List<String>, pkg: String): List<String> =
        if (pkg in list) list.filter { it != pkg } else list + pkg
}
