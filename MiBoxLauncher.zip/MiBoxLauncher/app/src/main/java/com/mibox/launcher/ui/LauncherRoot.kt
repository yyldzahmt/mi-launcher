package com.mibox.launcher.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import com.mibox.launcher.apps.AppEntry
import com.mibox.launcher.apps.IconCache
import com.mibox.launcher.data.LauncherModel
import com.mibox.launcher.system.SystemStatus
import com.mibox.launcher.system.loadBackground

enum class Screen { HOME, SETTINGS, APPS }

interface HostActions {
    fun launch(app: AppEntry)
    fun openAppDetails(pkg: String)
    fun pickBackgroundImage()
    fun openDefaultLauncherSettings()
    fun isDefaultHome(): Boolean
}

@Composable
fun LauncherRoot(
    model: LauncherModel,
    icons: IconCache,
    status: SystemStatus,
    screen: Screen,
    resetTick: Int,
    resumeTick: Int,
    host: HostActions,
    onScreen: (Screen) -> Unit,
) {
    val prefs by model.store.state.collectAsState()
    val ui by model.ui.collectAsState()
    val ctx = LocalContext.current
    val scale = (LocalConfiguration.current.screenWidthDp / 1280f).coerceIn(0.6f, 1.8f)
    val colors = remember(prefs.darkTheme, prefs.bgIndex) { colorsFor(prefs.darkTheme, prefs.bgIndex) }

    val bg by produceState<ImageBitmap?>(null, prefs.bgImageUri) {
        value = null
        value = prefs.bgImageUri?.let { loadBackground(ctx, it, 1280, 720) }
    }

    CompositionLocalProvider(
        LocalColors provides colors,
        LocalUiScale provides scale,
        LocalIcons provides icons,
    ) {
        Box(Modifier.fillMaxSize().background(colors.bg)) {
            bg?.let {
                Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                // Okunabilirlik icin yari saydam ortu
                Box(Modifier.fillMaxSize().background(colors.bg.copy(alpha = 0.72f)))
            }
            when (screen) {
                Screen.HOME -> HomeScreen(
                    model = model, status = status, prefs = prefs, ui = ui, resetTick = resetTick,
                    onLaunch = host::launch,
                    onSettings = { onScreen(Screen.SETTINGS) },
                    onAppInfo = { host.openAppDetails(it.pkg) },
                )
                Screen.SETTINGS -> SettingsScreen(
                    prefs = prefs, store = model.store, host = host, resumeTick = resumeTick,
                    onApps = { onScreen(Screen.APPS) },
                    onBack = { onScreen(Screen.HOME) },
                )
                Screen.APPS -> AppsScreen(
                    model = model, prefs = prefs, ui = ui,
                    onBack = { onScreen(Screen.SETTINGS) },
                )
            }
        }
    }
}
