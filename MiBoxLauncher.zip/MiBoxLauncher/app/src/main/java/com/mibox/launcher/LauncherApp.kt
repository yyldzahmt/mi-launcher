package com.mibox.launcher

import android.app.Application
import com.mibox.launcher.apps.AppRepository
import com.mibox.launcher.apps.IconCache
import com.mibox.launcher.data.LauncherModel
import com.mibox.launcher.data.PrefsStore
import com.mibox.launcher.system.DebugLog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

class LauncherApp : Application() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    lateinit var store: PrefsStore
        private set
    lateinit var repo: AppRepository
        private set
    lateinit var icons: IconCache
        private set
    lateinit var model: LauncherModel
        private set

    override fun onCreate() {
        super.onCreate()
        store = PrefsStore(this)
        DebugLog.dirProvider = { getExternalFilesDir(null) ?: filesDir }
        DebugLog.enabled = store.state.value.debugLog
        repo = AppRepository(this, scope)
        icons = IconCache(this)
        model = LauncherModel(repo, store, scope)
        repo.onPackageChanged = { pkg -> if (pkg != null) icons.remove(pkg) }
        repo.registerPackageReceiver()
        repo.refresh()
        scope.launch {
            store.state.map { it.debugLog }.distinctUntilChanged().collect { DebugLog.enabled = it }
        }
    }
}
