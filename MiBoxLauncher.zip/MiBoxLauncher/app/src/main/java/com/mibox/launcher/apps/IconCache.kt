package com.mibox.launcher.apps

import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.util.LruCache
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import com.mibox.launcher.system.DebugLog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Simgeler istek aninda arka planda yuklenir, ~6 MB'lik LRU onbellekte tutulur. */
class IconCache(context: Context) {
    private val pm = context.packageManager

    private val cache = object : LruCache<String, ImageBitmap>(6 * 1024 * 1024) {
        override fun sizeOf(key: String, value: ImageBitmap): Int = value.width * value.height * 4
    }

    /** Bir simge gecersiz kilindiginda artar; kartlar yeniden yuklenir. */
    var version by mutableIntStateOf(0)
        private set

    fun peek(pkg: String): ImageBitmap? = cache.get(pkg)

    suspend fun get(app: AppEntry): ImageBitmap? = withContext(Dispatchers.IO) {
        cache.get(app.pkg)?.let { return@withContext it }
        try {
            val d = pm.getActivityIcon(ComponentName(app.pkg, app.cls))
            val bmp = d.toBitmap(ICON_PX, ICON_PX, Bitmap.Config.ARGB_8888).asImageBitmap()
            cache.put(app.pkg, bmp)
            bmp
        } catch (e: Exception) {
            DebugLog.e("icon", "load failed ${app.pkg}", e)
            null
        }
    }

    fun remove(pkg: String) {
        cache.remove(pkg)
        version++
    }

    private companion object {
        const val ICON_PX = 128
    }
}
