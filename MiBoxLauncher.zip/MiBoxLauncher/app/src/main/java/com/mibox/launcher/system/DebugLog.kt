package com.mibox.launcher.system

import android.util.Log
import java.io.File

/** Yalnizca kullanici Ayarlar'dan acarsa dosyaya yazar (en fazla ~200 KB). Disariya hicbir sey gonderilmez. */
object DebugLog {
    @Volatile var enabled = false
    var dirProvider: (() -> File?)? = null

    fun e(tag: String, msg: String, t: Throwable? = null) {
        Log.e("MiLauncher/$tag", msg, t)
        write("E/$tag: $msg ${t?.toString() ?: ""}")
    }

    private fun write(line: String) {
        if (!enabled) return
        synchronized(this) {
            try {
                val dir = dirProvider?.invoke() ?: return
                val f = File(dir, "launcher.log")
                if (f.length() > 200_000) f.delete()
                f.appendText("${System.currentTimeMillis()} $line\n")
            } catch (_: Exception) {
            }
        }
    }
}
