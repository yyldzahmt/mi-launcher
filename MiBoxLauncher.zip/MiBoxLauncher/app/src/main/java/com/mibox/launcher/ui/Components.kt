package com.mibox.launcher.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.nativeKeyEvent
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.layout.layout
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.offset
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.mibox.launcher.apps.AppEntry
import com.mibox.launcher.data.AnimLevel
import com.mibox.launcher.data.CardSize
import kotlinx.coroutines.delay

/** OK/Enter: kisa basis = tikla, basili tutma = uzun tikla (D-pad kumanda icin). */
fun Modifier.tvClickable(onLongClick: (() -> Unit)?, onClick: () -> Unit): Modifier = composed {
    val state = remember { booleanArrayOf(false, false) } // [basili, uzunTetiklendi]
    val click by rememberUpdatedState(onClick)
    val long by rememberUpdatedState(onLongClick)
    onKeyEvent { e ->
        if (e.key != Key.DirectionCenter && e.key != Key.Enter && e.key != Key.NumPadEnter) {
            false
        } else when (e.type) {
            KeyEventType.KeyDown -> {
                if (e.nativeKeyEvent.repeatCount == 0) {
                    state[0] = true
                    state[1] = false
                } else if (!state[1]) {
                    val l = long
                    if (l != null) {
                        state[1] = true
                        l()
                    }
                }
                true
            }
            KeyEventType.KeyUp -> {
                val fire = state[0] && !state[1]
                state[0] = false
                state[1] = false
                if (fire) click()
                true
            }
            else -> false
        }
    }
}

/** Genisligi iki yandan [extra] kadar tasirir (LazyRow'un kenar kirpilmasini onlemek icin). */
fun Modifier.bleed(extra: Dp): Modifier = layout { measurable, constraints ->
    val e = extra.roundToPx()
    val p = measurable.measure(constraints.offset(horizontal = e * 2))
    layout(constraints.maxWidth, p.height) { p.place(-e, 0) }
}

suspend fun FocusRequester.requestSafely() {
    repeat(4) {
        if (runCatching { requestFocus() }.isSuccess) return
        delay(60)
    }
}

/** Odaklanabilir yuzey: odakta renk degisir, halka cizilir, istenirse hafifce buyur. */
@Composable
fun FocusBox(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(12.u()),
    focusScale: Float = 1f,
    animate: Boolean = false,
    normal: Color = LocalColors.current.surface,
    focused: Color = LocalColors.current.surfaceFocused,
    ring: Boolean = true,
    onLongClick: (() -> Unit)? = null,
    onClick: () -> Unit,
    content: @Composable BoxScope.(Boolean) -> Unit,
) {
    val c = LocalColors.current
    var isFocused by remember { mutableStateOf(false) }
    val target = if (isFocused) focusScale else 1f
    val scale = if (animate) animateFloatAsState(target, tween(110), label = "focusScale")
    else rememberUpdatedState(target)
    Box(
        modifier = modifier
            .graphicsLayer { scaleX = scale.value; scaleY = scale.value }
            .background(if (isFocused) focused else normal, shape)
            .then(if (isFocused && ring) Modifier.border(3.u(), c.accent, shape) else Modifier)
            .tvClickable(onLongClick, onClick)
            .onFocusChanged { isFocused = it.isFocused }
            .focusable(),
        content = { content(this, isFocused) },
    )
}

@Composable
fun AppIcon(app: AppEntry, size: Dp) {
    val icons = LocalIcons.current
    val bmp by produceState<ImageBitmap?>(icons.peek(app.pkg), app.pkg, icons.version) {
        value = icons.peek(app.pkg) ?: icons.get(app)
    }
    Box(Modifier.size(size)) {
        bmp?.let { Image(it, null, Modifier.fillMaxSize()) }
    }
}

@Composable
fun AppCard(
    app: AppEntry,
    size: CardSize,
    anim: AnimLevel,
    modifier: Modifier = Modifier,
    onLongClick: () -> Unit,
    onClick: () -> Unit,
) {
    val c = LocalColors.current
    val d = cardDims(size)
    FocusBox(
        modifier = modifier.size(d.w.u(), d.h.u()),
        shape = RoundedCornerShape(16.u()),
        focusScale = when (anim) {
            AnimLevel.FULL -> 1.08f
            AnimLevel.REDUCED -> 1.04f
            AnimLevel.OFF -> 1f
        },
        animate = anim == AnimLevel.FULL,
        onLongClick = onLongClick,
        onClick = onClick,
    ) { focused ->
        Column(
            Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            AppIcon(app, d.icon.u())
            Spacer(Modifier.height(10.u()))
            BasicText(
                app.label,
                style = TextStyle(
                    color = if (focused) c.text else c.textDim,
                    fontSize = d.font.us(),
                    textAlign = TextAlign.Center,
                    fontWeight = if (focused) FontWeight.Medium else FontWeight.Normal,
                ),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(horizontal = 8.u()),
            )
        }
    }
}

class MenuAction(val label: String, val keepOpen: Boolean = false, val run: () -> Unit)

/** Uzun OK ile acilan menu. Dialog penceresi odagi hapseder, Geri tusu kapatir. */
@Composable
fun ActionMenu(title: String, actions: List<MenuAction>, onDismiss: () -> Unit) {
    val c = LocalColors.current
    val first = remember { FocusRequester() }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier
                .width(440.u())
                .clip(RoundedCornerShape(20.u()))
                .background(c.surface)
                .padding(20.u()),
            verticalArrangement = Arrangement.spacedBy(6.u()),
        ) {
            BasicText(
                title,
                style = TextStyle(color = c.textDim, fontSize = 16.us(), fontWeight = FontWeight.Medium),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(start = 12.u(), bottom = 8.u()),
            )
            actions.forEachIndexed { i, a ->
                FocusBox(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.u())
                        .then(if (i == 0) Modifier.focusRequester(first) else Modifier),
                    shape = RoundedCornerShape(12.u()),
                    normal = Color.Transparent,
                    focused = c.accent,
                    ring = false,
                    onClick = {
                        a.run()
                        if (!a.keepOpen) onDismiss()
                    },
                ) { f ->
                    BasicText(
                        a.label,
                        style = TextStyle(color = if (f) c.onAccent else c.text, fontSize = 18.us()),
                        modifier = Modifier.align(Alignment.CenterStart).padding(start = 16.u()),
                    )
                }
            }
        }
    }
    LaunchedEffect(Unit) { first.requestSafely() }
}

@Composable
fun SettingRow(title: String, value: String? = null, firstRequester: FocusRequester? = null, onClick: () -> Unit) {
    val c = LocalColors.current
    FocusBox(
        modifier = Modifier
            .fillMaxWidth()
            .then(if (firstRequester != null) Modifier.focusRequester(firstRequester) else Modifier)
            .height(58.u()),
        shape = RoundedCornerShape(12.u()),
        onClick = onClick,
    ) {
        androidx.compose.foundation.layout.Row(
            Modifier.fillMaxSize().padding(horizontal = 22.u()),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            BasicText(
                title,
                style = TextStyle(color = c.text, fontSize = 19.us()),
                modifier = Modifier.weight(1f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            if (value != null) {
                BasicText(value, style = TextStyle(color = c.accent, fontSize = 19.us(), fontWeight = FontWeight.Medium))
            }
        }
    }
}
