package com.mibox.launcher.system

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat

enum class NetKind { WIFI, ETHERNET, OTHER, OFFLINE, UNKNOWN }

/**
 * Saat ve ag durumu. Dongu/polling yok: saat ACTION_TIME_TICK ile (dakikada bir, sistem gonderir),
 * ag NetworkCallback ile guncellenir. Yalnizca ekran gorunurken (onStart..onStop) dinlenir.
 */
class SystemStatus(private val context: Context) {
    var now by mutableLongStateOf(System.currentTimeMillis())
        private set
    var net by mutableStateOf(NetKind.UNKNOWN)
        private set

    private var callback: ConnectivityManager.NetworkCallback? = null
    private var timeRegistered = false

    private val timeReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            now = System.currentTimeMillis()
        }
    }

    fun start() {
        now = System.currentTimeMillis()
        if (!timeRegistered) {
            val f = IntentFilter().apply {
                addAction(Intent.ACTION_TIME_TICK)
                addAction(Intent.ACTION_TIME_CHANGED)
                addAction(Intent.ACTION_TIMEZONE_CHANGED)
            }
            ContextCompat.registerReceiver(context, timeReceiver, f, ContextCompat.RECEIVER_EXPORTED)
            timeRegistered = true
        }
        startNet()
    }

    fun stop() {
        if (timeRegistered) {
            try { context.unregisterReceiver(timeReceiver) } catch (_: Exception) {}
            timeRegistered = false
        }
        val cm = context.getSystemService(ConnectivityManager::class.java)
        callback?.let { cb -> try { cm?.unregisterNetworkCallback(cb) } catch (_: Exception) {} }
        callback = null
    }

    private fun kindOf(c: NetworkCapabilities?): NetKind = when {
        c == null -> NetKind.OFFLINE
        c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> NetKind.WIFI
        c.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> NetKind.ETHERNET
        c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) -> NetKind.OTHER
        else -> NetKind.OFFLINE
    }

    private fun currentKind(cm: ConnectivityManager): NetKind {
        val n = cm.activeNetwork ?: return NetKind.OFFLINE
        return kindOf(cm.getNetworkCapabilities(n))
    }

    private fun startNet() {
        if (callback != null) return
        val cm = context.getSystemService(ConnectivityManager::class.java) ?: return
        try {
            net = currentKind(cm)
            val cb = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) { net = kindOf(cm.getNetworkCapabilities(network)) }
                override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) { net = kindOf(caps) }
                override fun onLost(network: Network) { net = currentKind(cm) }
            }
            cm.registerDefaultNetworkCallback(cb)
            callback = cb
        } catch (e: Exception) {
            DebugLog.e("net", "ag durumu okunamadi", e)
        }
    }
}
