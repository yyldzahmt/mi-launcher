package com.mibox.launcher.apps

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import androidx.core.content.ContextCompat
import com.mibox.launcher.system.DebugLog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.text.Collator
import java.util.Locale

/** Yuklu uygulamalari PackageManager ile tarar. Yalnizca kurulum/kaldirma/guncelleme olunca yeniden tarar. */
class AppRepository(private val context: Context, private val scope: CoroutineScope) {
    private val pm = context.packageManager
    private val _apps = MutableStateFlow<List<AppEntry>>(emptyList())
    val apps: StateFlow<List<AppEntry>> = _apps
    private val _loaded = MutableStateFlow(false)
    val loaded: StateFlow<Boolean> = _loaded

    @Volatile private var job: Job? = null
    var onPackageChanged: ((String?) -> Unit)? = null

    fun refresh(debounceMs: Long = 0L) {
        job?.cancel()
        job = scope.launch(Dispatchers.IO) {
            if (debounceMs > 0) delay(debounceMs)
            val list = try {
                scan()
            } catch (e: Exception) {
                DebugLog.e("scan", "tarama basarisiz", e)
                null
            }
            if (list != null) {
                _apps.value = list
                _loaded.value = true
            }
        }
    }

    private fun scan(): List<AppEntry> {
        val result = LinkedHashMap<String, AppEntry>()
        fun query(category: String) {
            val intent = Intent(Intent.ACTION_MAIN).addCategory(category)
            for (ri in pm.queryIntentActivities(intent, 0)) {
                val ai = ri.activityInfo ?: continue
                if (!ai.exported) continue
                if (ai.packageName == context.packageName) continue
                if (result.containsKey(ai.packageName)) continue
                val label = ri.loadLabel(pm).toString()
                result[ai.packageName] = AppEntry(ai.packageName, ai.name, label)
            }
        }
        query(Intent.CATEGORY_LEANBACK_LAUNCHER) // TV uygulamalari once
        query(Intent.CATEGORY_LAUNCHER)          // yalnizca LAUNCHER olan (yandan yuklenen) uygulamalar
        val collator = Collator.getInstance(Locale("tr", "TR"))
        return result.values.sortedWith { a, b -> collator.compare(a.label, b.label) }
    }

    /** Uygulama sureci boyunca bir kez kaydedilir; ek servis gerektirmez. */
    fun registerPackageReceiver() {
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_REPLACED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) {
                onPackageChanged?.invoke(i?.data?.schemeSpecificPart)
                refresh(400)
            }
        }
        // Sistem yayinlari (korumali) icin EXPORTED guvenlidir; sahte yayin gonderilemez.
        ContextCompat.registerReceiver(context, receiver, filter, ContextCompat.RECEIVER_EXPORTED)
    }
}
