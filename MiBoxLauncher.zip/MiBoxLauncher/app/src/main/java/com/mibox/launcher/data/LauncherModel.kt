package com.mibox.launcher.data

import com.mibox.launcher.apps.AppEntry
import com.mibox.launcher.apps.AppOrdering
import com.mibox.launcher.apps.AppRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn

data class UiModel(
    val favorites: List<AppEntry> = emptyList(),
    val recents: List<AppEntry> = emptyList(),
    val all: List<AppEntry> = emptyList(),
    /** Gizlenenler dahil tum uygulamalar (yonetim ekrani). */
    val manage: List<AppEntry> = emptyList(),
    val loaded: Boolean = false,
)

class LauncherModel(
    val repo: AppRepository,
    val store: PrefsStore,
    scope: CoroutineScope,
) {
    val ui: StateFlow<UiModel> =
        combine(repo.apps, repo.loaded, store.state) { apps, loaded, p ->
            val visible = apps.filter { it.pkg !in p.hidden }
            val byPkg = visible.associateBy { it.pkg }
            UiModel(
                favorites = p.favorites.mapNotNull { byPkg[it] },
                recents = p.recents.mapNotNull { byPkg[it] },
                all = AppOrdering.applyOrder(visible, p.order),
                manage = apps,
                loaded = loaded,
            )
        }.stateIn(scope, SharingStarted.Eagerly, UiModel())

    fun toggleFavorite(pkg: String) =
        store.update { it.copy(favorites = AppOrdering.toggle(it.favorites, pkg)) }

    fun moveFavorite(pkg: String, delta: Int) =
        store.update { it.copy(favorites = AppOrdering.move(it.favorites, pkg, delta)) }

    fun moveInAll(pkg: String, delta: Int) {
        val current = ui.value.all.map { it.pkg }
        store.update { it.copy(order = AppOrdering.move(current, pkg, delta)) }
    }

    fun setHidden(pkg: String, hidden: Boolean) =
        store.update { it.copy(hidden = if (hidden) it.hidden + pkg else it.hidden - pkg) }

    fun recordLaunch(pkg: String) =
        store.update { it.copy(recents = AppOrdering.pushRecent(it.recents, pkg)) }
}
