package com.mibox.launcher.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mibox.launcher.apps.IconCache
import com.mibox.launcher.data.CardSize

@Immutable
class LColors(
    val bg: Color,
    val surface: Color,
    val surfaceFocused: Color,
    val text: Color,
    val textDim: Color,
    val accent: Color,
    val onAccent: Color,
)

val BgPresetNames = listOf("Antrasit", "Siyah", "Lacivert", "Orman yeşili", "Bordo")
private val BgPresetColors = listOf(
    Color(0xFF0F1115), Color(0xFF000000), Color(0xFF0A1220), Color(0xFF0B1A14), Color(0xFF1A0F14),
)

fun colorsFor(dark: Boolean, bgIndex: Int): LColors =
    if (dark) {
        LColors(
            bg = BgPresetColors[bgIndex.coerceIn(0, BgPresetColors.lastIndex)],
            surface = Color(0xFF1C1F26),
            surfaceFocused = Color(0xFF30353F),
            text = Color(0xFFF3F4F6),
            textDim = Color(0xFFA0A7B4),
            accent = Color(0xFF6AA9FF),
            onAccent = Color(0xFF06101F),
        )
    } else {
        LColors(
            bg = Color(0xFFF2F3F6),
            surface = Color(0xFFFFFFFF),
            surfaceFocused = Color(0xFFDDE3EE),
            text = Color(0xFF14161A),
            textDim = Color(0xFF5B6270),
            accent = Color(0xFF1F6FEB),
            onAccent = Color.White,
        )
    }

val LocalColors = staticCompositionLocalOf { colorsFor(true, 0) }
val LocalUiScale = staticCompositionLocalOf { 1f }
val LocalIcons = staticCompositionLocalOf<IconCache> { error("IconCache yok") }

/** Tasarim 1280dp genislik uzerinden yapildi; farkli TV yogunluklarinda oranlanir. */
@Composable fun Int.u(): Dp = (this * LocalUiScale.current).dp
@Composable fun Int.us(): TextUnit = (this * LocalUiScale.current).sp

class CardDims(val w: Int, val h: Int, val icon: Int, val font: Int, val cols: Int)

fun cardDims(s: CardSize): CardDims = when (s) {
    CardSize.SMALL -> CardDims(124, 108, 50, 14, 8)
    CardSize.MEDIUM -> CardDims(150, 128, 62, 15, 7)
    CardSize.LARGE -> CardDims(172, 150, 76, 17, 6)
}
