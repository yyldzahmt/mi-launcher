package com.mibox.launcher.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import com.mibox.launcher.apps.AppEntry
import com.mibox.launcher.data.AnimLevel
import com.mibox.launcher.data.CardSize
import com.mibox.launcher.data.LauncherModel
import com.mibox.launcher.data.LauncherPrefs
import com.mibox.launcher.data.UiModel
import com.mibox.launcher.system.NetKind
import com.mibox.launcher.system.SystemStatus
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private enum class Origin { FAV, RECENT, ALL }
private class MenuTarget(val app: AppEntry, val origin: Origin)

@Composable
fun HomeScreen(
    model: LauncherModel,
    status: SystemStatus,
    prefs: LauncherPrefs,
    ui: UiModel,
    resetTick: Int,
    onLaunch: (AppEntry) -> Unit,
    onSettings: () -> Unit,
    onAppInfo: (AppEntry) -> Unit,
) {
    val c = LocalColors.current
    val scope = rememberCoroutineScope()
    val gridState = rememberLazyGridState()
    val firstReq = remember { FocusRequester() }
    var menu by remember { mutableStateOf<MenuTarget?>(null) }

    val d = cardDims(prefs.cardSize)
    val showFav = ui.favorites.isNotEmpty()
    val showRec = prefs.showRecents && ui.recents.isNotEmpty()
    val firstAllPkg = ui.all.firstOrNull()?.pkg

    fun refocus() {
        scope.launch {
            delay(150)
            gridState.scrollToItem(0)
            delay(50)
            firstReq.requestSafely()
        }
    }

    // Acilista, Home tusuna basinca ve uygulamalar yuklendiginde ilk karta odaklan.
    LaunchedEffect(resetTick, ui.all.isNotEmpty()) {
        menu = null
        if (ui.all.isNotEmpty()) {
            gridState.scrollToItem(0)
            delay(80)
            firstReq.requestSafely()
        }
    }

    // Launcher'dan Geri ile cikilmaz; basa doner.
    BackHandler { refocus() }

    Column(Modifier.fillMaxSize()) {
        TopBar(status, prefs.showClock, onSettings)

        LazyVerticalGrid(
            columns = GridCells.Fixed(d.cols),
            state = gridState,
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 56.u(), end = 56.u(), top = 4.u(), bottom = 40.u()),
            horizontalArrangement = Arrangement.spacedBy(16.u()),
            verticalArrangement = Arrangement.spacedBy(16.u()),
        ) {
            if (showFav) {
                item(key = "fav", span = { GridItemSpan(maxLineSpan) }) {
                    Column {
                        SectionTitle("Favoriler")
                        AppRow(
                            apps = ui.favorites, prefix = "fav:", size = prefs.cardSize, anim = prefs.anim,
                            firstReq = firstReq,
                            onClick = onLaunch,
                            onLong = { menu = MenuTarget(it, Origin.FAV) },
                        )
                    }
                }
            }
            if (showRec) {
                item(key = "rec", span = { GridItemSpan(maxLineSpan) }) {
                    Column {
                        SectionTitle("Son kullanılanlar")
                        AppRow(
                            apps = ui.recents, prefix = "rec:", size = prefs.cardSize, anim = prefs.anim,
                            firstReq = if (!showFav) firstReq else null,
                            onClick = onLaunch,
                            onLong = { menu = MenuTarget(it, Origin.RECENT) },
                        )
                    }
                }
            }
            item(key = "allHeader", span = { GridItemSpan(maxLineSpan) }) {
                SectionTitle("Tüm uygulamalar")
            }
            items(ui.all, key = { "all:" + it.pkg }) { app ->
                val isFirst = !showFav && !showRec && app.pkg == firstAllPkg
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    AppCard(
                        app = app, size = prefs.cardSize, anim = prefs.anim,
                        modifier = if (isFirst) Modifier.focusRequester(firstReq) else Modifier,
                        onLongClick = { menu = MenuTarget(app, Origin.ALL) },
                        onClick = { onLaunch(app) },
                    )
                }
            }
        }
    }

    if (ui.loaded && ui.all.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            BasicText("Uygulama bulunamadı", style = TextStyle(color = c.textDim, fontSize = 22.us()))
        }
    }

    menu?.let { t ->
        val pkg = t.app.pkg
        val isFav = pkg in prefs.favorites
        val actions = buildList {
            add(MenuAction(if (isFav) "Favorilerden çıkar" else "Favorilere ekle") {
                model.toggleFavorite(pkg)
                if (t.origin == Origin.FAV && isFav) refocus()
            })
            if (t.origin == Origin.FAV) {
                add(MenuAction("Sola taşı", keepOpen = true) { model.moveFavorite(pkg, -1) })
                add(MenuAction("Sağa taşı", keepOpen = true) { model.moveFavorite(pkg, 1) })
            }
            if (t.origin == Origin.ALL) {
                add(MenuAction("Sola taşı", keepOpen = true) { model.moveInAll(pkg, -1) })
                add(MenuAction("Sağa taşı", keepOpen = true) { model.moveInAll(pkg, 1) })
            }
            add(MenuAction("Ana ekrandan gizle") {
                model.setHidden(pkg, true)
                refocus()
            })
            add(MenuAction("Uygulama bilgisi") { onAppInfo(t.app) })
            add(MenuAction("Vazgeç") {})
        }
        ActionMenu(t.app.label, actions) { menu = null }
    }
}

@Composable
private fun SectionTitle(text: String) {
    val c = LocalColors.current
    BasicText(
        text,
        style = TextStyle(color = c.text, fontSize = 22.us(), fontWeight = FontWeight.SemiBold),
        modifier = Modifier.padding(top = 8.u()),
    )
}

@Composable
private fun AppRow(
    apps: List<AppEntry>,
    prefix: String,
    size: CardSize,
    anim: AnimLevel,
    firstReq: FocusRequester?,
    onClick: (AppEntry) -> Unit,
    onLong: (AppEntry) -> Unit,
) {
    LazyRow(
        modifier = Modifier.bleed(56.u()).fillMaxWidth(),
        contentPadding = PaddingValues(horizontal = 56.u(), vertical = 12.u()),
        horizontalArrangement = Arrangement.spacedBy(16.u()),
    ) {
        itemsIndexed(apps, key = { _, a -> prefix + a.pkg }) { i, app ->
            AppCard(
                app = app, size = size, anim = anim,
                modifier = if (i == 0 && firstReq != null) Modifier.focusRequester(firstReq) else Modifier,
                onLongClick = { onLong(app) },
                onClick = { onClick(app) },
            )
        }
    }
}

@Composable
private fun TopBar(status: SystemStatus, showClock: Boolean, onSettings: () -> Unit) {
    val c = LocalColors.current
    Row(
        Modifier.fillMaxWidth().padding(start = 56.u(), end = 56.u(), top = 26.u(), bottom = 10.u()),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (showClock) ClockBlock(status)
        Spacer(Modifier.weight(1f))
        NetPill(status)
        Spacer(Modifier.width(20.u()))
        FocusBox(
            modifier = Modifier.height(46.u()),
            shape = RoundedCornerShape(24.u()),
            onClick = onSettings,
        ) {
            BasicText(
                "Ayarlar",
                style = TextStyle(color = c.text, fontSize = 18.us(), fontWeight = FontWeight.Medium),
                modifier = Modifier.align(Alignment.Center).padding(horizontal = 24.u()),
            )
        }
    }
}

@Composable
private fun ClockBlock(status: SystemStatus) {
    val c = LocalColors.current
    val timeFmt = remember { SimpleDateFormat("HH:mm", Locale("tr", "TR")) }
    val dateFmt = remember { SimpleDateFormat("d MMMM, EEEE", Locale("tr", "TR")) }
    val d = Date(status.now)
    Column {
        BasicText(timeFmt.format(d), style = TextStyle(color = c.text, fontSize = 44.us(), fontWeight = FontWeight.Bold))
        BasicText(dateFmt.format(d), style = TextStyle(color = c.textDim, fontSize = 16.us()))
    }
}

@Composable
private fun NetPill(status: SystemStatus) {
    val c = LocalColors.current
    val net = status.net
    if (net == NetKind.UNKNOWN) return
    val green = Color(0xFF4CD08A)
    val (label, color) = when (net) {
        NetKind.WIFI -> "Wi-Fi bağlı" to green
        NetKind.ETHERNET -> "Ethernet bağlı" to green
        NetKind.OTHER -> "Bağlı" to green
        else -> "Çevrimdışı" to Color(0xFFE0645C)
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(10.u()).background(color, CircleShape))
        Spacer(Modifier.width(8.u()))
        BasicText(label, style = TextStyle(color = c.textDim, fontSize = 16.us()))
    }
}
