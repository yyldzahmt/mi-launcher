package com.mibox.launcher.apps

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import com.mibox.launcher.system.DebugLog

object AppLauncher {
    /** Uygulamayi baslatir; basarisizsa false doner. */
    fun launch(ctx: Context, app: AppEntry): Boolean {
        try {
            val i = Intent(Intent.ACTION_MAIN)
                .setComponent(ComponentName(app.pkg, app.cls))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            ctx.startActivity(i)
            return true
        } catch (e: Exception) {
            DebugLog.e("launch", "bilesen ile baslatma basarisiz ${app.pkg}", e)
        }
        return try {
            val pm = ctx.packageManager
            val i = pm.getLeanbackLaunchIntentForPackage(app.pkg) ?: pm.getLaunchIntentForPackage(app.pkg)
            if (i == null) {
                false
            } else {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(i)
                true
            }
        } catch (e: Exception) {
            DebugLog.e("launch", "yedek baslatma basarisiz ${app.pkg}", e)
            false
        }
    }
}
