package com.mibox.launcher

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.mibox.launcher.apps.AppEntry
import com.mibox.launcher.apps.AppLauncher
import com.mibox.launcher.system.DefaultLauncher
import com.mibox.launcher.system.SystemStatus
import com.mibox.launcher.ui.HostActions
import com.mibox.launcher.ui.LauncherRoot
import com.mibox.launcher.ui.Screen

class MainActivity : ComponentActivity(), HostActions {
    private val app: LauncherApp get() = application as LauncherApp

    private var screen by mutableStateOf(Screen.HOME)
    private var resetTick by mutableIntStateOf(0)
    private var resumeTick by mutableIntStateOf(0)
    private lateinit var status: SystemStatus

    private val pickImage = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {
            }
            app.store.update { it.copy(bgImageUri = uri.toString()) }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        status = SystemStatus(applicationContext)
        setContent {
            LauncherRoot(
                model = app.model,
                icons = app.icons,
                status = status,
                screen = screen,
                resetTick = resetTick,
                resumeTick = resumeTick,
                host = this,
                onScreen = { screen = it },
            )
        }
    }

    override fun onStart() {
        super.onStart()
        status.start()
    }

    override fun onStop() {
        status.stop()
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        resumeTick++
    }

    /** Ana ekran tusuna basildiginda (singleTask) ana ekrana don. */
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        screen = Screen.HOME
        resetTick++
    }

    // ---- HostActions ----

    override fun launch(app: AppEntry) {
        if (AppLauncher.launch(this, app)) {
            this.app.model.recordLaunch(app.pkg)
        } else {
            toast("${app.label} başlatılamadı")
        }
    }

    override fun openAppDetails(pkg: String) {
        if (!DefaultLauncher.openAppDetails(this, pkg)) toast("Uygulama bilgisi bu cihazda açılamadı")
    }

    override fun pickBackgroundImage() {
        try {
            pickImage.launch(arrayOf("image/*"))
        } catch (_: ActivityNotFoundException) {
            toast("Bu cihazda dosya seçici bulunamadı")
        }
    }

    override fun openDefaultLauncherSettings() {
        if (!DefaultLauncher.openSelection(this)) toast("Sistem ayarları açılamadı")
    }

    override fun isDefaultHome(): Boolean = DefaultLauncher.isDefaultHome(this)

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
