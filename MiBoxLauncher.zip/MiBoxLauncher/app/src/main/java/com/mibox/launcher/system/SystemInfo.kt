package com.mibox.launcher.system

import android.app.ActivityManager
import android.content.Context
import android.os.Build

fun systemInfoLines(ctx: Context): List<Pair<String, String>> {
    val version = try {
        ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "?"
    } catch (_: Exception) {
        "?"
    }
    val mem = try {
        val am = ctx.getSystemService(ActivityManager::class.java)
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        "${mi.availMem / 1048576} / ${mi.totalMem / 1048576} MB bos"
    } catch (_: Exception) {
        "?"
    }
    return listOf(
        "Uygulama sürümü" to version,
        "Cihaz" to "${Build.MANUFACTURER} ${Build.MODEL}",
        "Android" to "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
        "Bellek" to mem,
    )
}
