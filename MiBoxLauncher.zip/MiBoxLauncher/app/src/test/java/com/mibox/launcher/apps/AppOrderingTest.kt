package com.mibox.launcher.apps

import org.junit.Assert.assertEquals
import org.junit.Test

class AppOrderingTest {
    private fun app(p: String) = AppEntry(p, "$p.Main", p.uppercase())
    private val apps = listOf(app("a"), app("b"), app("c"), app("d"))

    @Test fun storedOrderFirstThenRestAlphabetical() {
        val r = AppOrdering.applyOrder(apps, listOf("c", "a", "zzz")).map { it.pkg }
        assertEquals(listOf("c", "a", "b", "d"), r)
    }

    @Test fun moveSwapsAndClamps() {
        val l = listOf("a", "b", "c")
        assertEquals(listOf("b", "a", "c"), AppOrdering.move(l, "a", 1))
        assertEquals(l, AppOrdering.move(l, "a", -1))
        assertEquals(l, AppOrdering.move(l, "x", 1))
    }

    @Test fun recentsDedupAndCap() {
        val r = AppOrdering.pushRecent(listOf("a", "b", "c"), "b", max = 3)
        assertEquals(listOf("b", "a", "c"), r)
        assertEquals(2, AppOrdering.pushRecent(listOf("a", "b"), "c", max = 2).size)
    }

    @Test fun toggleAddsAndRemoves() {
        assertEquals(listOf("a", "b"), AppOrdering.toggle(listOf("a"), "b"))
        assertEquals(listOf("a"), AppOrdering.toggle(listOf("a", "b"), "b"))
    }
}
