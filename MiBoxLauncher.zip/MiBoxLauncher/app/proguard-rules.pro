# Ozel kural gerekmiyor; Compose ve coroutines kendi tuketici kurallarini getirir.
